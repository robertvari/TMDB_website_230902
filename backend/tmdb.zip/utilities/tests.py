genres = ["Action", "Adventure", "War"]

print(", ".join(genres))